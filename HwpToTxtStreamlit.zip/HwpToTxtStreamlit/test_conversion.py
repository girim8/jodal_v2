#!/usr/bin/env python3
"""
Test script to verify HWP conversion methods work with the provided document
"""

import olefile
import zipfile
import chardet
import io
from lxml import etree

# Target keyword to verify
VERIFICATION_KEYWORD = "스쿨넷"

def test_method1_olefile(file_path):
    """Test Method 1: OLE File extraction"""
    print("\n" + "="*80)
    print("Testing Method 1: OLE File Extraction")
    print("="*80)
    
    try:
        with open(file_path, 'rb') as f:
            hwp_data = f.read()
        
        ole = olefile.OleFileIO(hwp_data)
        streams = ole.listdir()
        print(f"Found {len(streams)} streams in OLE file")
        
        # List all streams
        print("\nAvailable streams:")
        for stream in streams:
            stream_name = '/'.join(stream)
            try:
                size = ole.get_size(stream)
                print(f"  - {stream_name} ({size:,} bytes)")
            except:
                print(f"  - {stream_name}")
        
        extracted_text = []
        
        # Try to extract text from each stream
        for stream_path in streams:
            stream_name = '/'.join(stream_path)
            
            try:
                data = ole.openstream(stream_path).read()
                
                # Try different encodings
                for encoding in ['utf-16le', 'utf-8', 'cp949', 'euc-kr']:
                    try:
                        text = data.decode(encoding, errors='ignore')
                        if text and len(text) > 10:
                            # Check if this contains Korean text
                            has_korean = any('\uac00' <= char <= '\ud7a3' for char in text)
                            if has_korean:
                                print(f"\n  Found Korean text in stream: {stream_name} (encoding: {encoding})")
                                print(f"  Text length: {len(text)} characters")
                                
                                # Check for verification keyword
                                if VERIFICATION_KEYWORD in text:
                                    print(f"  ✅ FOUND '{VERIFICATION_KEYWORD}'!")
                                    extracted_text.append(text)
                                else:
                                    print(f"  ❌ '{VERIFICATION_KEYWORD}' not found in this stream")
                                
                                # Show snippet
                                korean_snippet = ''.join([c for c in text if '\uac00' <= c <= '\ud7a3'])[:100]
                                if korean_snippet:
                                    print(f"  Korean snippet: {korean_snippet[:50]}...")
                            break
                    except:
                        continue
            except:
                continue
        
        ole.close()
        
        if extracted_text:
            combined = '\n'.join(extracted_text)
            if VERIFICATION_KEYWORD in combined:
                print(f"\n✅ SUCCESS! Method 1 found '{VERIFICATION_KEYWORD}'")
                print(f"Total extracted characters: {len(combined)}")
                return True, combined
            else:
                print(f"\n❌ FAIL! '{VERIFICATION_KEYWORD}' not found in combined text")
                return False, combined
        else:
            print("\n❌ FAIL! No Korean text extracted")
            return False, None
            
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False, None

def test_method2_hwpx(file_path):
    """Test Method 2: HWPX ZIP extraction"""
    print("\n" + "="*80)
    print("Testing Method 2: HWPX ZIP Extraction")
    print("="*80)
    
    try:
        with open(file_path, 'rb') as f:
            hwp_data = f.read()
        
        zip_file = zipfile.ZipFile(io.BytesIO(hwp_data))
        file_list = zip_file.namelist()
        
        print(f"Found {len(file_list)} files in HWPX archive:")
        for fname in file_list:
            print(f"  - {fname}")
        
        extracted_text = []
        
        for filename in file_list:
            if filename.endswith('.xml'):
                try:
                    xml_data = zip_file.read(filename)
                    
                    # Try to parse as XML
                    try:
                        root = etree.fromstring(xml_data)
                        text_elements = root.xpath('//text()')
                        text = ' '.join(text_elements)
                        
                        if text and len(text) > 10:
                            has_korean = any('\uac00' <= char <= '\ud7a3' for char in text)
                            if has_korean:
                                print(f"\n  Found Korean text in: {filename}")
                                print(f"  Text length: {len(text)}")
                                
                                if VERIFICATION_KEYWORD in text:
                                    print(f"  ✅ FOUND '{VERIFICATION_KEYWORD}'!")
                                    extracted_text.append(text)
                                else:
                                    print(f"  ❌ '{VERIFICATION_KEYWORD}' not found")
                    except:
                        # Try as plain text
                        for encoding in ['utf-8', 'utf-16le', 'cp949', 'euc-kr']:
                            try:
                                text = xml_data.decode(encoding, errors='ignore')
                                if text and len(text) > 10:
                                    has_korean = any('\uac00' <= char <= '\ud7a3' for char in text)
                                    if has_korean and VERIFICATION_KEYWORD in text:
                                        print(f"\n  ✅ Found '{VERIFICATION_KEYWORD}' in {filename} (encoding: {encoding})")
                                        extracted_text.append(text)
                                        break
                            except:
                                continue
                except:
                    continue
        
        zip_file.close()
        
        if extracted_text:
            combined = '\n'.join(extracted_text)
            if VERIFICATION_KEYWORD in combined:
                print(f"\n✅ SUCCESS! Method 2 found '{VERIFICATION_KEYWORD}'")
                return True, combined
            else:
                print(f"\n❌ FAIL! '{VERIFICATION_KEYWORD}' not found")
                return False, combined
        else:
            print("\n❌ FAIL! No text extracted from HWPX")
            return False, None
            
    except zipfile.BadZipFile:
        print("\n❌ Not a valid ZIP/HWPX file")
        return False, None
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False, None

def test_method3_libreoffice(file_path):
    """Test Method 3: LibreOffice conversion"""
    print("\n" + "="*80)
    print("Testing Method 3: LibreOffice Conversion")
    print("="*80)
    
    try:
        import subprocess
        import tempfile
        import os
        
        with open(file_path, 'rb') as f:
            hwp_data = f.read()
        
        # Save to temp file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.hwp') as tmp_hwp:
            tmp_hwp.write(hwp_data)
            tmp_hwp_path = tmp_hwp.name
        
        output_path = tmp_hwp_path.replace('.hwp', '.txt')
        
        print(f"Running unoconv on {tmp_hwp_path}...")
        result = subprocess.run(
            ['unoconv', '-f', 'txt', '-o', output_path, tmp_hwp_path],
            capture_output=True,
            timeout=60
        )
        
        print(f"Exit code: {result.returncode}")
        if result.stdout:
            print(f"STDOUT: {result.stdout.decode('utf-8', errors='ignore')}")
        if result.stderr:
            print(f"STDERR: {result.stderr.decode('utf-8', errors='ignore')}")
        
        if os.path.exists(output_path):
            with open(output_path, 'rb') as f:
                text_data = f.read()
            
            # Detect encoding
            detected = chardet.detect(text_data)
            encoding = detected['encoding']
            confidence = detected['confidence']
            
            print(f"Detected encoding: {encoding} (confidence: {confidence:.2f})")
            
            text = text_data.decode(encoding if encoding else 'utf-8', errors='ignore')
            
            print(f"Extracted {len(text)} characters")
            
            # Clean up
            os.unlink(tmp_hwp_path)
            os.unlink(output_path)
            
            if VERIFICATION_KEYWORD in text:
                print(f"✅ SUCCESS! Method 3 found '{VERIFICATION_KEYWORD}'")
                return True, text
            else:
                has_korean = any('\uac00' <= char <= '\ud7a3' for char in text)
                if has_korean:
                    print(f"❌ FAIL! Korean text found but '{VERIFICATION_KEYWORD}' missing")
                else:
                    print(f"❌ FAIL! No Korean text detected")
                return False, text
        else:
            os.unlink(tmp_hwp_path)
            print("❌ FAIL! Conversion produced no output")
            return False, None
            
    except FileNotFoundError:
        print("❌ LibreOffice/unoconv not found")
        return False, None
    except Exception as e:
        print(f"❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False, None

if __name__ == '__main__':
    test_file = 'attached_assets/20210430609-00_1618895289680_4단계 스쿨넷 사업 제안요청서(조달청 추가 의견 반영본) - 복사본_1762740838248.hwp'
    
    print("="*80)
    print(f"Testing HWP to TXT conversion with verification keyword: '{VERIFICATION_KEYWORD}'")
    print(f"Test file: {test_file}")
    print("="*80)
    
    results = []
    
    # Test Method 1
    success1, text1 = test_method1_olefile(test_file)
    results.append(("Method 1: OLE File", success1, text1))
    
    # Test Method 2
    success2, text2 = test_method2_hwpx(test_file)
    results.append(("Method 2: HWPX ZIP", success2, text2))
    
    # Test Method 3
    success3, text3 = test_method3_libreoffice(test_file)
    results.append(("Method 3: LibreOffice", success3, text3))
    
    # Summary
    print("\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    
    for method_name, success, text in results:
        status = "✅ PASS" if success else "❌ FAIL"
        text_len = len(text) if text else 0
        print(f"{status} {method_name} - {text_len} chars")
    
    # Show first successful method
    successful = [r for r in results if r[1]]
    if successful:
        print(f"\n🎉 First successful method: {successful[0][0]}")
        print(f"\nExtracted text preview (first 500 chars):")
        print("-" * 80)
        print(successful[0][2][:500])
        print("-" * 80)
    else:
        print("\n❌ All methods failed to extract '{VERIFICATION_KEYWORD}'")
