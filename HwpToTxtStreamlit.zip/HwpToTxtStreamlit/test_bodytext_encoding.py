#!/usr/bin/env python3
"""
Test different encoding strategies for HWP BodyText extraction
"""

import olefile
import zlib
import chardet

test_file = 'attached_assets/20210430609-00_1618895289680_4단계 스쿨넷 사업 제안요청서(조달청 추가 의견 반영본) - 복사본_1762740838248.hwp'

# Keywords to verify
KEYWORDS = ['스쿨넷', '추정금액', '이중화', 'Aggregation']

print("="*80)
print("Testing BodyText Encoding Strategies")
print("="*80)

with open(test_file, 'rb') as f:
    hwp_data = f.read()

ole = olefile.OleFileIO(hwp_data)

# Find BodyText section
bodytext_stream = None
for stream_path in ole.listdir():
    stream_name = '/'.join(stream_path)
    if 'BodyText/Section0' in stream_name:
        bodytext_stream = stream_path
        break

if not bodytext_stream:
    print("BodyText/Section0 not found!")
    exit(1)

raw_data = ole.openstream(bodytext_stream).read()
print(f"\nBodyText/Section0 size: {len(raw_data):,} bytes")

# Try decompression
print("\n" + "-"*80)
print("Attempting zlib decompression...")
print("-"*80)

try:
    decompressed = zlib.decompress(raw_data)
    print(f"✓ Successfully decompressed: {len(decompressed):,} bytes")
    data_to_decode = decompressed
except Exception as e:
    print(f"✗ Decompression failed: {e}")
    print("Using raw data instead")
    data_to_decode = raw_data

# Try chardet detection
print("\n" + "-"*80)
print("Chardet encoding detection...")
print("-"*80)
detected = chardet.detect(data_to_decode[:10000])  # Sample first 10KB
print(f"Detected: {detected['encoding']} (confidence: {detected['confidence']:.2%})")

# Try multiple encoding strategies
encodings_to_try = [
    'utf-16le',
    'utf-16be', 
    'utf-8',
    'utf-8-sig',
    'euc-kr',
    'cp949',
    'iso-8859-1',
    'latin1',
]

print("\n" + "="*80)
print("Testing Encodings")
print("="*80)

results = []

for encoding in encodings_to_try:
    print(f"\n{encoding}:")
    print("-" * 40)
    
    try:
        # Decode
        text = data_to_decode.decode(encoding, errors='ignore')
        
        # Count Korean characters
        korean_count = sum(1 for c in text if '\uac00' <= c <= '\ud7a3')
        total_chars = len(text)
        korean_ratio = korean_count / total_chars if total_chars > 0 else 0
        
        print(f"  Total chars: {total_chars:,}")
        print(f"  Korean chars: {korean_count:,} ({korean_ratio:.1%})")
        
        # Check for keywords
        found_keywords = []
        for keyword in KEYWORDS:
            if keyword in text:
                found_keywords.append(keyword)
        
        print(f"  Keywords found: {found_keywords}")
        
        # Show sample Korean text
        korean_chars = [c for c in text if '\uac00' <= c <= '\ud7a3']
        if korean_chars:
            sample = ''.join(korean_chars[:50])
            print(f"  Sample: {sample}...")
        
        # Score this encoding
        keyword_score = len(found_keywords)
        score = keyword_score * 100 + korean_ratio * 10
        
        results.append({
            'encoding': encoding,
            'korean_count': korean_count,
            'korean_ratio': korean_ratio,
            'keywords_found': found_keywords,
            'score': score,
            'text': text
        })
        
    except Exception as e:
        print(f"  ✗ Error: {e}")

# Sort by score
results.sort(key=lambda x: x['score'], reverse=True)

print("\n" + "="*80)
print("RESULTS SUMMARY (Best to Worst)")
print("="*80)

for i, result in enumerate(results[:5], 1):
    print(f"\n{i}. {result['encoding']}")
    print(f"   Korean: {result['korean_count']:,} ({result['korean_ratio']:.1%})")
    print(f"   Keywords: {result['keywords_found']}")
    print(f"   Score: {result['score']:.1f}")

# Show best result
if results:
    best = results[0]
    print("\n" + "="*80)
    print(f"BEST ENCODING: {best['encoding']}")
    print("="*80)
    print(f"Keywords found: {best['keywords_found']}")
    print(f"\nFirst 1000 characters:")
    print("-" * 80)
    print(best['text'][:1000])
    
    if len(best['keywords_found']) == len(KEYWORDS):
        print("\n✅ SUCCESS! All keywords found!")
    else:
        missing = set(KEYWORDS) - set(best['keywords_found'])
        print(f"\n⚠️ Missing keywords: {missing}")

ole.close()
